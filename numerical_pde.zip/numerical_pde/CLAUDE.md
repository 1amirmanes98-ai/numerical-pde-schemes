# CLAUDE.md - PDE Numerical Schemes Project

## Project Overview

This project implements numerical schemes for solving dispersive PDE systems as part of a Numerical Analysis exam (Question 3).

**PDE System:**
```
u_t = i*A*u_xx + C*u + F(x),  x ∈ [0,1], t ≥ 0
```

With:
- A = [[0,1],[1,0]] (Hermitian, eigenvalues ±1)
- C = [[3,-1],[-1,3]] (eigenvalues +2, +4 — causes solution growth)
- F(x) = I*cos(2ωx), ω = 2π
- Initial condition: u(0,x) = [cos(ωx), -i*sin(ωx)]^T
- Periodic boundary conditions

## File Structure

```
pde_schemes_final.py    # Main implementation (354 lines)
```

## Implemented Schemes

| Scheme | Type | Order | Stability |
|--------|------|-------|-----------|
| Forward Euler | Explicit | O(k) + O(h²) | Unstable for dispersive |
| Backward Euler | Implicit | O(k) + O(h²) | Unconditionally stable |
| Leap Frog | Explicit 2-step | O(k²) + O(h²) | CFL: k ≤ h²/4 |
| Crank-Nicholson | Implicit | O(k²) + O(h²) | Unconditionally stable |
| DuFort-Frankel | Explicit 2-step | O(k²) + O(h²) + O(k²/h²) | Needs k = o(h) |

## Key Functions

### Matrix Building
- `build_Dxx(N, h)` — Periodic second derivative matrix
- `build_L(N, h, C)` — Full system matrix L = i*A⊗Dxx + C⊗I_N

### Schemes
- `forward_euler(N, h, k, T, C)` — Returns None if unstable
- `backward_euler(N, h, k, T, C)`
- `leap_frog(N, h, k, T, C)` — Uses RK2 for initialization
- `crank_nicholson(N, h, k, T, C)`
- `dufort_frankel(N, h, k, T, C)`

### Reference Solution
- `exact_solution(x, t, C)` — Fourier spectral method with matrix exponential

### Error Analysis
- `L2_error(u_num, u_exact, h)` — Discrete L² norm
- `rate(e1, e2)` — Convergence rate via log₂(e1/e2)

## Time Step Strategies

```python
Forward Euler:     k = 0.1 * h²     # Will be unstable anyway
Backward Euler:    k = h²           # Match spatial error
Leap Frog:         k = 0.2 * h²     # CFL: k < h²/4
Crank-Nicholson:   k = h            # O(k²) = O(h²)
DuFort-Frankel:    k = 0.5 * h²     # p=2 for consistency
```

## Running the Code

```bash
python pde_schemes_final.py
```

Output includes:
1. Convergence study for STABLE case (C with negative eigenvalues)
2. Convergence study for ORIGINAL Q3 (C with positive eigenvalues)
3. DuFort-Frankel p-test (p = 1, 1.5, 2)

## Expected Results

### Main Convergence Table (Original Q3, T=0.1)
| Scheme | Rate |
|--------|------|
| Forward Euler | Unstable |
| Backward Euler | ~2.0 |
| Leap Frog | ~2.0 |
| Crank-Nicholson | ~2.0 |
| DuFort-Frankel (p=2) | ~2.0 |

### DuFort-Frankel p-test
- p=1: Rate ≈ 0 (inconsistent)
- p=1.5: Rate ≈ 1
- p=2: Rate ≈ 2

## Key Theoretical Points

1. **Forward Euler fails** because dispersive equations have eigenvalues on imaginary axis, outside FE stability region

2. **Positive C eigenvalues** cause solution growth ~e^{4t}, but implicit schemes remain stable

3. **DuFort-Frankel consistency** requires k²/h² → 0, i.e., k = o(h)

4. **Leap Frog CFL**: k ≤ h²/(4|λ_max|) = h²/4

## Dependencies

```
numpy
scipy (linalg, sparse, fft)
matplotlib (optional, for plotting)
```

## Common Tasks

### Add a new scheme
1. Create function `new_scheme(N, h, k, T, C)` following existing pattern
2. Add to `schemes` dict in `run_study()`
3. Add time step strategy in `get_k()`

### Change test parameters
- Modify `N_vals` for grid sizes
- Modify `T` for final time
- Modify `C_stable` or `C_original` matrices

### Generate convergence plot
```python
# After run_study(), add:
plt.loglog(1/np.array(N_vals), errors, 'o-', label=name)
plt.xlabel('h'); plt.ylabel('Error')
plt.legend(); plt.savefig('convergence.png')
```

## Debugging Tips

- If scheme returns `None`, it blew up (check time step)
- If rates are wrong, check matrix assembly (Kronecker products)
- For DuFort-Frankel, ensure off-diagonal Dxx is correct
- Verify exact solution by checking initial condition recovery

## Code Style

- Use NumPy broadcasting where possible
- Sparse matrices for large N
- Flatten/reshape with `order='F'` for column-major (Fortran) ordering to match Kronecker structure
