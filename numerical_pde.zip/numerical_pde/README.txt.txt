# Numerical PDE Schemes for Dispersive Equations

Numerical Analysis Final Exam — Prof. Adi Ditkowski, Tel Aviv University, January 2026

## Problem

Solve the dispersive PDE system on [0,1] with periodic boundary conditions:

$$u_t = i A u_{xx} + C u + F(x)$$

**Matrices:**
- $A = \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix}$ — Hermitian, eigenvalues ±1
- $C = \begin{pmatrix} 3 & -1 \\ -1 & 3 \end{pmatrix}$ — eigenvalues +2, +4 (causes exponential growth)

**Initial condition:** $u(0,x) = (\cos(2\pi x), -i\sin(2\pi x))^T$

**Forcing:** $F(x) = I \cos(4\pi x)$

---

## Implemented Schemes

| Scheme | Type | Truncation Error | Stability |
|--------|------|------------------|-----------|
| Forward Euler | Explicit | O(k) + O(h²) | **Unstable** for dispersive |
| Backward Euler | Implicit | O(k) + O(h²) | Unconditionally stable |
| Leap Frog | Explicit 2-step | O(k²) + O(h²) | CFL: k ≤ h²/4 |
| Crank–Nicolson | Implicit | O(k²) + O(h²) | Unconditionally stable |
| Du Fort–Frankel | Explicit 2-step | O(k²) + O(h²) + O(k²/h²) | Requires k = o(h) |

---

## Results

### Convergence — Original Q3 (C eigenvalues: +2, +4, T=0.1)

![Convergence Original](convergence_original_q3.png)

| Scheme | N=16 | N=32 | N=64 | N=128 | Rate |
|--------|------|------|------|-------|------|
| Forward Euler | Unstable | Unstable | Unstable | Unstable | — |
| Backward Euler | 3.50e-1 | 9.98e-2 | 2.56e-2 | 6.46e-3 | ≈1.9 |
| Leap Frog | 6.83e-2 | 1.73e-2 | 4.34e-3 | 1.08e-3 | ≈2.0 |
| Crank–Nicolson | 6.38e-1 | 1.97e-1 | 4.65e-2 | 1.20e-2 | ≈1.9 |
| Du Fort–Frankel | 2.52e-1 | 6.75e-2 | 1.73e-2 | 4.34e-3 | ≈2.0 |

### Convergence — Stable Case (C eigenvalues: -2, -4, T=0.5)

![Convergence Stable](convergence_stable.png)

### Du Fort–Frankel Consistency Test (k = λh^p)

| p | Rate | Consistent? |
|---|------|-------------|
| 1 | ≈ -0.1 | **NO** — converges to wrong equation |
| 1.5 | ≈ 0.8 | Yes |
| 2 | ≈ 2.0 | Yes |

---

## Key Findings

1. **Forward Euler is unconditionally unstable** — dispersive eigenvalues lie on imaginary axis, outside FE stability region

2. **Leap Frog achieves best accuracy** — clean O(h²) convergence, smallest absolute errors

3. **Du Fort–Frankel requires k = o(h)** — using k = O(h) causes convergence to the wrong equation

4. **Stability ≠ Convergence** — even with |g| > 1, convergence is preserved for finite T because numerical solution tracks exact solution's exponential growth

---

## Usage

```bash
python pde_schemes_final.py
```

**Output:**
1. Convergence study for stable case (C < 0)
2. Convergence study for original Q3 (C > 0)  
3. Du Fort–Frankel consistency test (p = 1, 1.5, 2)

---

## Files

```
pde_schemes_final.py        # Main implementation (380 lines)
convergence_original_q3.png # Plot: original C matrix
convergence_stable.png      # Plot: stable C matrix
exam_solutions.pdf          # Full LaTeX write-up (Q1, Q2, Q3)
README.md                   # This file
```

---

## Dependencies

```
numpy
scipy
matplotlib
```

---

## License

MIT